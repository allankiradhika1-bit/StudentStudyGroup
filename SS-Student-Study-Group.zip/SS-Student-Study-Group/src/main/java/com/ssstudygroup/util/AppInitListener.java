package com.ssstudygroup.util;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

/** Creates the database tables (and demo data) when the web app starts. */
public class AppInitListener implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        DBConnection.init();
        System.out.println("[SS Study Group] Database ready.");
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        // nothing to clean up: connections are opened and closed per request
    }
}
