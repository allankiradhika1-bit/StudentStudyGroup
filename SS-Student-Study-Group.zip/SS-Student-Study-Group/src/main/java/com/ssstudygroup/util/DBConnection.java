package com.ssstudygroup.util;

import com.ssstudygroup.dao.GroupDAO;
import com.ssstudygroup.dao.MembershipDAO;
import com.ssstudygroup.dao.StudentDAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Opens JDBC connections to an embedded H2 database stored in ./data/
 * (created automatically on first run, no database server needed).
 *
 * To use MySQL instead, change URL/USER/PASSWORD and swap the H2 dependency
 * in pom.xml for the MySQL connector.
 */
public class DBConnection {

    private static final String URL =
            System.getProperty("ssg.db.url", "jdbc:h2:file:./data/studygroup");
    private static final String USER = System.getProperty("ssg.db.user", "sa");
    private static final String PASSWORD = System.getProperty("ssg.db.password", "");

    static {
        try {
            Class.forName("org.h2.Driver");
        } catch (ClassNotFoundException e) {
            throw new ExceptionInInitializerError(e);
        }
    }

    private DBConnection() {}

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    /** Creates tables if missing and loads demo data on an empty database. */
    public static void init() {
        try (Connection c = getConnection(); Statement st = c.createStatement()) {
            st.execute("CREATE TABLE IF NOT EXISTS students ("
                    + "id BIGINT AUTO_INCREMENT PRIMARY KEY, "
                    + "name VARCHAR(100) NOT NULL, "
                    + "email VARCHAR(150) NOT NULL UNIQUE)");

            st.execute("CREATE TABLE IF NOT EXISTS study_groups ("
                    + "id BIGINT AUTO_INCREMENT PRIMARY KEY, "
                    + "name VARCHAR(80) NOT NULL, "
                    + "subject VARCHAR(60) NOT NULL, "
                    + "description VARCHAR(500), "
                    + "max_members INT NOT NULL, "
                    + "created_by BIGINT NOT NULL, "
                    + "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, "
                    + "FOREIGN KEY (created_by) REFERENCES students(id))");

            st.execute("CREATE TABLE IF NOT EXISTS memberships ("
                    + "id BIGINT AUTO_INCREMENT PRIMARY KEY, "
                    + "group_id BIGINT NOT NULL, "
                    + "student_id BIGINT NOT NULL, "
                    + "joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, "
                    + "UNIQUE (group_id, student_id), "
                    + "FOREIGN KEY (group_id) REFERENCES study_groups(id) ON DELETE CASCADE, "
                    + "FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE)");
        } catch (SQLException e) {
            throw new IllegalStateException("Could not initialise the database", e);
        }

        try {
            if (new StudentDAO().count() == 0) {
                seed();
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Could not seed demo data", e);
        }
    }

    private static void seed() throws SQLException {
        StudentDAO students = new StudentDAO();
        GroupDAO groups = new GroupDAO();
        MembershipDAO memberships = new MembershipDAO();

        long aarav = students.create("Aarav Sharma", "aarav@example.com").getId();
        long priya = students.create("Priya Reddy", "priya@example.com").getId();
        long rohan = students.create("Rohan Verma", "rohan@example.com").getId();
        long sneha = students.create("Sneha Iyer", "sneha@example.com").getId();
        long kiran = students.create("Kiran Kumar", "kiran@example.com").getId();
        long meera = students.create("Meera Nair", "meera@example.com").getId();
        long arjun = students.create("Arjun Rao", "arjun@example.com").getId();
        long vikram = students.create("Vikram Singh", "vikram@example.com").getId();
        long ananya = students.create("Ananya Das", "ananya@example.com").getId();

        long g1 = groups.create("Data Structures Crew", "Computer Science",
                "Weekly problem solving on trees, graphs and DP. Bring your laptop.", 8, aarav);
        long g2 = groups.create("Calculus Warriors", "Mathematics",
                "Limits, integrals and exam-style practice every Tuesday evening.", 6, priya);
        long g3 = groups.create("Organic Chem Circle", "Chemistry",
                "Reaction mechanisms made simple. Flashcards and past papers.", 5, meera);
        long g4 = groups.create("DBMS Deep Dive", "Computer Science",
                "SQL, normalization and transactions, with mock viva questions.", 4, rohan);
        long g5 = groups.create("Physics Problem Solvers", "Physics",
                "Mechanics and electromagnetism numericals, solved together.", 10, vikram);
        long g6 = groups.create("Literature Book Club", "English",
                "Discussing prescribed texts and practising essay writing.", 12, sneha);

        join(memberships, g1, aarav, priya, rohan, sneha, kiran);
        join(memberships, g2, priya, meera, arjun);
        join(memberships, g3, meera, sneha, vikram, ananya, rohan);   // full (5/5)
        join(memberships, g4, rohan, aarav, kiran);
        join(memberships, g5, vikram, ananya);
        join(memberships, g6, sneha, priya, meera, ananya, arjun, kiran);
    }

    private static void join(MembershipDAO dao, long groupId, long... studentIds) throws SQLException {
        for (long sid : studentIds) {
            dao.join(groupId, sid);
        }
    }
}
