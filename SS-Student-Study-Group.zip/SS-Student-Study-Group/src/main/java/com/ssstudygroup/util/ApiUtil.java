package com.ssstudygroup.util;

import com.google.gson.Gson;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Map;

/** Small helpers shared by the servlets: JSON output, errors and login lookup. */
public final class ApiUtil {

    public static final String SESSION_STUDENT_ID = "studentId";
    private static final Gson GSON = new Gson();

    private ApiUtil() {}

    public static void json(HttpServletResponse resp, int status, Object body) throws IOException {
        resp.setStatus(status);
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        resp.setHeader("Cache-Control", "no-store");
        resp.getWriter().write(GSON.toJson(body));
    }

    public static void error(HttpServletResponse resp, int status, String message) throws IOException {
        json(resp, status, Map.of("error", message));
    }

    public static void serverError(HttpServletResponse resp, Exception e) throws IOException {
        e.printStackTrace();
        error(resp, 500, "Something went wrong on the server. Please try again.");
    }

    /** Returns the logged-in student's id, or null when nobody is logged in. */
    public static Long currentStudentId(HttpServletRequest req) {
        HttpSession session = req.getSession(false);
        if (session == null) return null;
        Object id = session.getAttribute(SESSION_STUDENT_ID);
        return (id instanceof Long) ? (Long) id : null;
    }

    public static String param(HttpServletRequest req, String name) {
        String v = req.getParameter(name);
        return v == null ? "" : v.trim();
    }
}
