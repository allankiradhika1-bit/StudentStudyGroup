package com.ssstudygroup.model;

public class StudyGroup {
    private long id;
    private String name;
    private String subject;
    private String description;
    private int maxMembers;
    private long createdBy;
    private String createdAt;
    private String creatorName;

    // Derived values (filled by the DAO, sent to the browser as JSON)
    private int memberCount;
    private int seatsLeft;
    private boolean full;
    private boolean joined;

    public StudyGroup() {}

    public void refreshDerived() {
        this.seatsLeft = Math.max(0, maxMembers - memberCount);
        this.full = memberCount >= maxMembers;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getSubject() { return subject; }
    public void setSubject(String subject) { this.subject = subject; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public int getMaxMembers() { return maxMembers; }
    public void setMaxMembers(int maxMembers) { this.maxMembers = maxMembers; }
    public long getCreatedBy() { return createdBy; }
    public void setCreatedBy(long createdBy) { this.createdBy = createdBy; }
    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }
    public String getCreatorName() { return creatorName; }
    public void setCreatorName(String creatorName) { this.creatorName = creatorName; }
    public int getMemberCount() { return memberCount; }
    public void setMemberCount(int memberCount) { this.memberCount = memberCount; }
    public int getSeatsLeft() { return seatsLeft; }
    public boolean isFull() { return full; }
    public boolean isJoined() { return joined; }
    public void setJoined(boolean joined) { this.joined = joined; }
}
