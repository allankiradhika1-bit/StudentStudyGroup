package com.ssstudygroup.model;

public class Membership {
    private long id;
    private long groupId;
    private long studentId;
    private String studentName;
    private String studentEmail;
    private String joinedAt;
    private boolean creator;

    public Membership() {}

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }
    public long getGroupId() { return groupId; }
    public void setGroupId(long groupId) { this.groupId = groupId; }
    public long getStudentId() { return studentId; }
    public void setStudentId(long studentId) { this.studentId = studentId; }
    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }
    public String getStudentEmail() { return studentEmail; }
    public void setStudentEmail(String studentEmail) { this.studentEmail = studentEmail; }
    public String getJoinedAt() { return joinedAt; }
    public void setJoinedAt(String joinedAt) { this.joinedAt = joinedAt; }
    public boolean isCreator() { return creator; }
    public void setCreator(boolean creator) { this.creator = creator; }
}
