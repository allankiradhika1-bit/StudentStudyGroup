package com.ssstudygroup.servlet;

import com.ssstudygroup.dao.MembershipDAO;
import com.ssstudygroup.util.ApiUtil;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;

/** POST /api/leave  groupId=...  -- leaves a group the student belongs to. */
public class LeaveServlet extends HttpServlet {

    private final MembershipDAO memberships = new MembershipDAO();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Long sid = ApiUtil.currentStudentId(req);
        if (sid == null) {
            ApiUtil.error(resp, 401, "Please log in first.");
            return;
        }

        long groupId;
        try {
            groupId = Long.parseLong(ApiUtil.param(req, "groupId"));
        } catch (NumberFormatException e) {
            ApiUtil.error(resp, 400, "Invalid group id.");
            return;
        }

        try {
            if (memberships.leave(groupId, sid)) {
                ApiUtil.json(resp, 200, Map.of("message", "You left the group."));
            } else {
                ApiUtil.error(resp, 404, "You are not a member of this group.");
            }
        } catch (SQLException e) {
            ApiUtil.serverError(resp, e);
        }
    }
}
