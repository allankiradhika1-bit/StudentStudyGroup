package com.ssstudygroup.servlet;

import com.ssstudygroup.dao.GroupDAO;
import com.ssstudygroup.dao.MembershipDAO;
import com.ssstudygroup.model.StudyGroup;
import com.ssstudygroup.util.ApiUtil;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * /api/groups
 *   GET  ?q=&available=true&mine=true   list / search groups
 *   GET  ?id=5                          one group plus its member list
 *   POST name, subject, description, maxMembers   create a group (creator auto-joins)
 *   POST action=delete&groupId=5        delete a group (creator only)
 */
public class GroupServlet extends HttpServlet {

    private final GroupDAO groups = new GroupDAO();
    private final MembershipDAO memberships = new MembershipDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Long sid = ApiUtil.currentStudentId(req);
        if (sid == null) {
            ApiUtil.error(resp, 401, "Please log in first.");
            return;
        }
        try {
            String idParam = req.getParameter("id");
            if (idParam != null) {
                long id;
                try {
                    id = Long.parseLong(idParam.trim());
                } catch (NumberFormatException e) {
                    ApiUtil.error(resp, 400, "Invalid group id.");
                    return;
                }
                StudyGroup g = groups.findById(id, sid);
                if (g == null) {
                    ApiUtil.error(resp, 404, "Group not found.");
                    return;
                }
                Map<String, Object> out = new LinkedHashMap<>();
                out.put("group", g);
                out.put("members", memberships.findMembers(id));
                ApiUtil.json(resp, 200, out);
                return;
            }

            boolean available = "true".equals(req.getParameter("available"));
            boolean mine = "true".equals(req.getParameter("mine"));
            ApiUtil.json(resp, 200, groups.search(req.getParameter("q"), available, mine, sid));
        } catch (SQLException e) {
            ApiUtil.serverError(resp, e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        req.setCharacterEncoding("UTF-8");
        Long sid = ApiUtil.currentStudentId(req);
        if (sid == null) {
            ApiUtil.error(resp, 401, "Please log in first.");
            return;
        }

        try {
            if ("delete".equals(ApiUtil.param(req, "action"))) {
                long groupId;
                try {
                    groupId = Long.parseLong(ApiUtil.param(req, "groupId"));
                } catch (NumberFormatException e) {
                    ApiUtil.error(resp, 400, "Invalid group id.");
                    return;
                }
                if (groups.delete(groupId, sid)) {
                    ApiUtil.json(resp, 200, Map.of("message", "Group deleted."));
                } else {
                    ApiUtil.error(resp, 403, "Only the creator can delete this group.");
                }
                return;
            }

            String name = ApiUtil.param(req, "name");
            String subject = ApiUtil.param(req, "subject");
            String description = ApiUtil.param(req, "description");

            if (name.length() < 3 || name.length() > 80) {
                ApiUtil.error(resp, 400, "Group name must be 3 to 80 characters.");
                return;
            }
            if (subject.length() < 2 || subject.length() > 60) {
                ApiUtil.error(resp, 400, "Subject must be 2 to 60 characters.");
                return;
            }
            if (description.length() > 500) {
                ApiUtil.error(resp, 400, "Description can be at most 500 characters.");
                return;
            }
            int max;
            try {
                max = Integer.parseInt(ApiUtil.param(req, "maxMembers"));
            } catch (NumberFormatException e) {
                ApiUtil.error(resp, 400, "Maximum members must be a number.");
                return;
            }
            if (max < 2 || max > 100) {
                ApiUtil.error(resp, 400, "Maximum members must be between 2 and 100.");
                return;
            }

            long id = groups.create(name, subject, description, max, sid);
            memberships.join(id, sid);   // the creator is the first member

            Map<String, Object> out = new LinkedHashMap<>();
            out.put("id", id);
            out.put("message", "Group created.");
            ApiUtil.json(resp, 201, out);
        } catch (SQLException e) {
            ApiUtil.serverError(resp, e);
        }
    }
}
