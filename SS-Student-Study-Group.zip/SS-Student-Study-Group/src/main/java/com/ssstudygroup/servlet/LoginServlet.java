package com.ssstudygroup.servlet;

import com.ssstudygroup.dao.StudentDAO;
import com.ssstudygroup.model.Student;
import com.ssstudygroup.util.ApiUtil;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.regex.Pattern;

/**
 * One servlet, three URLs:
 *   POST /api/login   name + email  -> logs in (registers the student if new)
 *   POST /api/logout                -> ends the session
 *   GET  /api/me                    -> the current student, or 401
 */
public class LoginServlet extends HttpServlet {

    private static final Pattern EMAIL = Pattern.compile("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$");
    private final StudentDAO students = new StudentDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Long id = ApiUtil.currentStudentId(req);
        if (id == null) {
            ApiUtil.error(resp, 401, "Not logged in");
            return;
        }
        try {
            Student s = students.findById(id);
            if (s == null) {
                ApiUtil.error(resp, 401, "Not logged in");
                return;
            }
            ApiUtil.json(resp, 200, s);
        } catch (SQLException e) {
            ApiUtil.serverError(resp, e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        req.setCharacterEncoding("UTF-8");

        if ("/api/logout".equals(req.getServletPath())) {
            HttpSession session = req.getSession(false);
            if (session != null) session.invalidate();
            ApiUtil.json(resp, 200, java.util.Map.of("message", "Logged out"));
            return;
        }

        String name = ApiUtil.param(req, "name");
        String email = ApiUtil.param(req, "email");
        if (name.length() < 2 || name.length() > 100) {
            ApiUtil.error(resp, 400, "Please enter your name (2 to 100 characters).");
            return;
        }
        if (!EMAIL.matcher(email).matches() || email.length() > 150) {
            ApiUtil.error(resp, 400, "Please enter a valid email address.");
            return;
        }

        try {
            Student s = students.findOrCreate(name, email);
            HttpSession old = req.getSession(false);
            if (old != null) old.invalidate();          // fresh session on login
            req.getSession(true).setAttribute(ApiUtil.SESSION_STUDENT_ID, s.getId());
            ApiUtil.json(resp, 200, s);
        } catch (SQLException e) {
            ApiUtil.serverError(resp, e);
        }
    }
}
