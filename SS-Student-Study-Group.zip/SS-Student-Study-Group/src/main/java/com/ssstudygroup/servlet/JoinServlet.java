package com.ssstudygroup.servlet;

import com.ssstudygroup.dao.MembershipDAO;
import com.ssstudygroup.dao.MembershipDAO.JoinResult;
import com.ssstudygroup.util.ApiUtil;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;

/** POST /api/join  groupId=...  -- joins a group, rejected with 409 if it is full. */
public class JoinServlet extends HttpServlet {

    private final MembershipDAO memberships = new MembershipDAO();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Long sid = ApiUtil.currentStudentId(req);
        if (sid == null) {
            ApiUtil.error(resp, 401, "Please log in first.");
            return;
        }

        long groupId;
        try {
            groupId = Long.parseLong(ApiUtil.param(req, "groupId"));
        } catch (NumberFormatException e) {
            ApiUtil.error(resp, 400, "Invalid group id.");
            return;
        }

        try {
            JoinResult result = memberships.join(groupId, sid);
            switch (result) {
                case JOINED:
                    ApiUtil.json(resp, 200, Map.of("message", "You joined the group."));
                    break;
                case FULL:
                    ApiUtil.error(resp, 409, "This group is full. No places are left.");
                    break;
                case ALREADY_MEMBER:
                    ApiUtil.error(resp, 409, "You are already a member of this group.");
                    break;
                default:
                    ApiUtil.error(resp, 404, "Group not found.");
            }
        } catch (SQLException e) {
            ApiUtil.serverError(resp, e);
        }
    }
}
