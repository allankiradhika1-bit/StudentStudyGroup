package com.ssstudygroup.servlet;

import com.ssstudygroup.dao.GroupDAO;
import com.ssstudygroup.dao.MembershipDAO;
import com.ssstudygroup.dao.StudentDAO;
import com.ssstudygroup.model.StudyGroup;
import com.ssstudygroup.util.ApiUtil;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** GET /api/stats -- numbers for the dashboard cards and charts. */
public class StatsServlet extends HttpServlet {

    private final GroupDAO groups = new GroupDAO();
    private final StudentDAO students = new StudentDAO();
    private final MembershipDAO memberships = new MembershipDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Long sid = ApiUtil.currentStudentId(req);
        if (sid == null) {
            ApiUtil.error(resp, 401, "Please log in first.");
            return;
        }
        try {
            List<StudyGroup> all = groups.search("", false, false, sid);

            int fullGroups = 0, openSeats = 0, totalSeats = 0, filledSeats = 0, myGroups = 0;
            Map<String, Integer> bySubject = new LinkedHashMap<>();
            for (StudyGroup g : all) {
                if (g.isFull()) fullGroups++;
                if (g.isJoined()) myGroups++;
                openSeats += g.getSeatsLeft();
                totalSeats += g.getMaxMembers();
                filledSeats += g.getMemberCount();
                bySubject.merge(g.getSubject(), 1, Integer::sum);
            }

            List<Map<String, Object>> subjects = new ArrayList<>();
            for (Map.Entry<String, Integer> e : bySubject.entrySet()) {
                Map<String, Object> row = new LinkedHashMap<>();
                row.put("subject", e.getKey());
                row.put("count", e.getValue());
                subjects.add(row);
            }
            subjects.sort((a, b) -> (Integer) b.get("count") - (Integer) a.get("count"));

            Map<String, Object> out = new LinkedHashMap<>();
            out.put("totalGroups", all.size());
            out.put("totalStudents", students.count());
            out.put("totalMemberships", memberships.countAll());
            out.put("fullGroups", fullGroups);
            out.put("openSeats", openSeats);
            out.put("totalSeats", totalSeats);
            out.put("filledSeats", filledSeats);
            out.put("myGroups", myGroups);
            out.put("subjects", subjects);
            ApiUtil.json(resp, 200, out);
        } catch (SQLException e) {
            ApiUtil.serverError(resp, e);
        }
    }
}
