package com.ssstudygroup.dao;

import com.ssstudygroup.model.StudyGroup;
import com.ssstudygroup.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class GroupDAO {

    /** Every group query selects the same columns; "?" #1 is the viewing student's id. */
    private static final String BASE_SELECT =
            "SELECT g.id, g.name, g.subject, g.description, g.max_members, g.created_by, g.created_at, "
          + "(SELECT s.name FROM students s WHERE s.id = g.created_by) AS creator_name, "
          + "(SELECT COUNT(*) FROM memberships m WHERE m.group_id = g.id) AS member_count, "
          + "(SELECT COUNT(*) FROM memberships m2 WHERE m2.group_id = g.id AND m2.student_id = ?) AS joined "
          + "FROM study_groups g ";

    public long create(String name, String subject, String description, int maxMembers, long createdBy)
            throws SQLException {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "INSERT INTO study_groups (name, subject, description, max_members, created_by) "
                   + "VALUES (?, ?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, name);
            ps.setString(2, subject);
            ps.setString(3, description);
            ps.setInt(4, maxMembers);
            ps.setLong(5, createdBy);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                keys.next();
                return keys.getLong(1);
            }
        }
    }

    public StudyGroup findById(long id, long viewerId) throws SQLException {
        List<Object> params = new ArrayList<>();
        params.add(id);
        List<StudyGroup> rows = query(" WHERE g.id = ?", params, viewerId);
        return rows.isEmpty() ? null : rows.get(0);
    }

    /**
     * Lists groups. Optional filters: text (matches name or subject),
     * only groups with free places, only groups the viewer belongs to.
     */
    public List<StudyGroup> search(String text, boolean availableOnly, boolean mineOnly, long viewerId)
            throws SQLException {
        StringBuilder where = new StringBuilder(" WHERE 1 = 1");
        List<Object> params = new ArrayList<>();

        if (text != null && !text.isBlank()) {
            where.append(" AND (LOWER(g.name) LIKE ? OR LOWER(g.subject) LIKE ?)");
            String like = "%" + text.trim().toLowerCase() + "%";
            params.add(like);
            params.add(like);
        }
        if (availableOnly) {
            where.append(" AND (SELECT COUNT(*) FROM memberships a WHERE a.group_id = g.id) < g.max_members");
        }
        if (mineOnly) {
            where.append(" AND EXISTS (SELECT 1 FROM memberships x WHERE x.group_id = g.id AND x.student_id = ?)");
            params.add(viewerId);
        }
        return query(where.toString(), params, viewerId);
    }

    /** Only the creator can delete a group. Memberships are removed by ON DELETE CASCADE. */
    public boolean delete(long groupId, long requesterId) throws SQLException {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM study_groups WHERE id = ? AND created_by = ?")) {
            ps.setLong(1, groupId);
            ps.setLong(2, requesterId);
            return ps.executeUpdate() > 0;
        }
    }

    private List<StudyGroup> query(String where, List<Object> params, long viewerId) throws SQLException {
        String sql = BASE_SELECT + where + " ORDER BY g.id DESC";
        List<StudyGroup> out = new ArrayList<>();
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setLong(1, viewerId);
            for (int i = 0; i < params.size(); i++) {
                ps.setObject(i + 2, params.get(i));
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    out.add(map(rs));
                }
            }
        }
        return out;
    }

    private StudyGroup map(ResultSet rs) throws SQLException {
        StudyGroup g = new StudyGroup();
        g.setId(rs.getLong("id"));
        g.setName(rs.getString("name"));
        g.setSubject(rs.getString("subject"));
        g.setDescription(rs.getString("description"));
        g.setMaxMembers(rs.getInt("max_members"));
        g.setCreatedBy(rs.getLong("created_by"));
        g.setCreatorName(rs.getString("creator_name"));
        g.setMemberCount(rs.getInt("member_count"));
        g.setJoined(rs.getInt("joined") > 0);
        Timestamp ts = rs.getTimestamp("created_at");
        if (ts != null) {
            String text = ts.toLocalDateTime().toString().replace('T', ' ');
            g.setCreatedAt(text.length() > 16 ? text.substring(0, 16) : text);
        }
        g.refreshDerived();
        return g;
    }
}
