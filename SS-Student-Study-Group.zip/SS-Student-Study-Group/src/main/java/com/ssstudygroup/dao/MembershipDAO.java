package com.ssstudygroup.dao;

import com.ssstudygroup.model.Membership;
import com.ssstudygroup.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class MembershipDAO {

    public enum JoinResult { JOINED, FULL, ALREADY_MEMBER, GROUP_NOT_FOUND }

    /**
     * Adds a student to a group unless the group is at capacity.
     * The capacity check and the insert happen in one transaction, with the
     * group row locked, so two students can never take the last seat together.
     */
    public synchronized JoinResult join(long groupId, long studentId) throws SQLException {
        try (Connection c = DBConnection.getConnection()) {
            c.setAutoCommit(false);
            try {
                int max;
                try (PreparedStatement ps = c.prepareStatement(
                        "SELECT max_members FROM study_groups WHERE id = ? FOR UPDATE")) {
                    ps.setLong(1, groupId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) {
                            c.rollback();
                            return JoinResult.GROUP_NOT_FOUND;
                        }
                        max = rs.getInt(1);
                    }
                }

                if (count(c, "SELECT COUNT(*) FROM memberships WHERE group_id = ? AND student_id = ?",
                        groupId, studentId) > 0) {
                    c.rollback();
                    return JoinResult.ALREADY_MEMBER;
                }

                int current = count(c, "SELECT COUNT(*) FROM memberships WHERE group_id = ?", groupId);
                if (current >= max) {
                    c.rollback();
                    return JoinResult.FULL;
                }

                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT INTO memberships (group_id, student_id) VALUES (?, ?)")) {
                    ps.setLong(1, groupId);
                    ps.setLong(2, studentId);
                    ps.executeUpdate();
                }
                c.commit();
                return JoinResult.JOINED;
            } catch (SQLException e) {
                c.rollback();
                throw e;
            }
        }
    }

    /** Removes the student from the group. Returns false if they were not a member. */
    public boolean leave(long groupId, long studentId) throws SQLException {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "DELETE FROM memberships WHERE group_id = ? AND student_id = ?")) {
            ps.setLong(1, groupId);
            ps.setLong(2, studentId);
            return ps.executeUpdate() > 0;
        }
    }

    /** Members of one group, oldest first (the creator joins first). */
    public List<Membership> findMembers(long groupId) throws SQLException {
        String sql = "SELECT m.id, m.group_id, m.student_id, m.joined_at, s.name, s.email, "
                   + "(g.created_by = s.id) AS is_creator "
                   + "FROM memberships m "
                   + "JOIN students s ON s.id = m.student_id "
                   + "JOIN study_groups g ON g.id = m.group_id "
                   + "WHERE m.group_id = ? ORDER BY m.id";
        List<Membership> out = new ArrayList<>();
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setLong(1, groupId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Membership m = new Membership();
                    m.setId(rs.getLong("id"));
                    m.setGroupId(rs.getLong("group_id"));
                    m.setStudentId(rs.getLong("student_id"));
                    m.setStudentName(rs.getString("name"));
                    m.setStudentEmail(rs.getString("email"));
                    m.setCreator(rs.getBoolean("is_creator"));
                    Timestamp ts = rs.getTimestamp("joined_at");
                    if (ts != null) {
                        String text = ts.toLocalDateTime().toString().replace('T', ' ');
                        m.setJoinedAt(text.length() > 16 ? text.substring(0, 16) : text);
                    }
                    out.add(m);
                }
            }
        }
        return out;
    }

    public int countAll() throws SQLException {
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM memberships")) {
            rs.next();
            return rs.getInt(1);
        }
    }

    private int count(Connection c, String sql, long... args) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            for (int i = 0; i < args.length; i++) {
                ps.setLong(i + 1, args[i]);
            }
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1);
            }
        }
    }
}
