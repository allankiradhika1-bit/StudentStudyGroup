(async function () {
  const me = await requireLogin('groups');
  const grid = document.getElementById('grid');
  const q = document.getElementById('q');
  const availBtn = document.getElementById('availBtn');
  const mineBtn = document.getElementById('mineBtn');
  let available = false, mine = false, timer = null, seq = 0;

  async function load() {
    const mySeq = ++seq;   // ignore out-of-order responses while typing
    const params = new URLSearchParams();
    if (q.value.trim()) params.set('q', q.value.trim());
    if (available) params.set('available', 'true');
    if (mine) params.set('mine', 'true');
    try {
      const groups = await API.get('/api/groups?' + params.toString());
      if (mySeq !== seq) return;
      render(groups);
    } catch (e) {
      if (e.status === 401) { location.href = 'index.html'; return; }
      toast(e.message, true);
    }
  }

  function render(groups) {
    document.getElementById('count').textContent =
      groups.length + (groups.length === 1 ? ' group found' : ' groups found');
    if (!groups.length) {
      grid.innerHTML = '<div class="card empty" style="grid-column:1/-1">No groups match your search. Try different words, or <a href="create-group.html">create one</a>.</div>';
      return;
    }
    grid.innerHTML = groups.map(g => groupCard(g, me)).join('');
  }

  q.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(load, 250); });
  availBtn.onclick = () => { available = !available; availBtn.classList.toggle('on', available); load(); };
  mineBtn.onclick = () => { mine = !mine; mineBtn.classList.toggle('on', mine); load(); };

  bindGroupActions(grid, load);
  load();
})();
