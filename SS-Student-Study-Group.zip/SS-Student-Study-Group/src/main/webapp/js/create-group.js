(async function () {
  const me = await requireLogin('create');
  const form = document.getElementById('groupForm');
  const msg = document.getElementById('msg');
  const preview = document.getElementById('preview');

  function updatePreview() {
    const name = form.name.value.trim() || 'Your group name';
    const subject = form.subject.value.trim() || 'Subject';
    const max = Math.max(2, Math.min(100, parseInt(form.maxMembers.value, 10) || 2));
    const accent = colorFor(subject);
    const dots = Math.min(max, 24);
    document.getElementById('charCount').textContent = form.description.value.length;
    preview.innerHTML = `
      <span class="badge" style="background:${accent}22;color:${accent}">${esc(subject)}</span>
      <h3 style="margin:10px 0 4px">${esc(name)}</h3>
      <div class="meta muted" style="font-weight:600;font-size:.85rem">👤 1 / ${max} members</div>
      <div class="seat-dots">
        ${Array.from({ length: dots }, (_, i) => `<i class="${i === 0 ? 'on' : ''}"></i>`).join('')}
        ${max > 24 ? `<small class="muted">+${max - 24}</small>` : ''}
      </div>`;
  }
  form.addEventListener('input', updatePreview);
  updatePreview();

  form.addEventListener('submit', async ev => {
    ev.preventDefault();
    msg.textContent = '';
    const btn = document.getElementById('saveBtn');
    btn.disabled = true;
    try {
      const res = await API.post('/api/groups', {
        name: form.name.value,
        subject: form.subject.value,
        description: form.description.value,
        maxMembers: form.maxMembers.value
      });
      toast('Group created 🎉');
      setTimeout(() => { location.href = 'members.html?id=' + res.id; }, 500);
    } catch (e) {
      msg.textContent = e.message;
      btn.disabled = false;
    }
  });
})();
