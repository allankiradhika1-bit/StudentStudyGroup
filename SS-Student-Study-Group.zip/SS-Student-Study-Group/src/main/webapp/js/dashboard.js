(async function () {
  const me = await requireLogin('dashboard');
  document.getElementById('hello').textContent = 'Welcome back, ' + me.name.split(' ')[0] + ' 👋';

  async function load() {
    let stats, groups;
    try {
      [stats, groups] = await Promise.all([API.get('/api/stats'), API.get('/api/groups')]);
    } catch (e) {
      if (e.status === 401) { location.href = 'index.html'; return; }
      toast(e.message, true);
      return;
    }
    renderStats(stats);
    renderSubjects(stats.subjects, stats.totalGroups);
    renderSeatRing(stats);
    renderCapacity(groups);
    renderOpen(groups);
    renderMine(groups);
  }

  function renderStats(s) {
    const cards = [
      ['📚', 'Study groups', s.totalGroups, '#6366f1', '#e0e7ff'],
      ['🎓', 'Students', s.totalStudents, '#06b6d4', '#cffafe'],
      ['⭐', 'My groups', s.myGroups, '#ec4899', '#fce7f3'],
      ['🪑', 'Open seats', s.openSeats, '#10b981', '#d1fae5'],
      ['🔒', 'Full groups', s.fullGroups, '#ef4444', '#fee2e2']
    ];
    const box = document.getElementById('stats');
    box.innerHTML = cards.map(c => `
      <div class="card stat" style="--tint:${c[4]}">
        <div class="icon" style="background:${c[4]};color:${c[3]}">${c[0]}</div>
        <div class="num" data-n="${c[2]}">0</div>
        <div class="lbl">${c[1]}</div>
      </div>`).join('');
    box.querySelectorAll('.num').forEach(el => countUp(el, Number(el.dataset.n)));
  }

  function renderSubjects(subjects, total) {
    const el = document.getElementById('subjectChart');
    if (!subjects.length) { el.innerHTML = '<div class="empty">No groups yet.</div>'; return; }
    let offset = 0;
    const segs = subjects.map((s, i) => {
      const pct = s.count / total * 100;
      const seg = `<circle class="seg" r="15.9155" cx="21" cy="21" fill="transparent" stroke="${COLORS[i % COLORS.length]}"
        stroke-width="5" stroke-dasharray="${pct} ${100 - pct}" stroke-dashoffset="${25 - offset}"></circle>`;
      offset += pct;
      return seg;
    }).join('');
    el.innerHTML = `
      <svg viewBox="0 0 42 42" class="donut">
        <circle r="15.9155" cx="21" cy="21" fill="transparent" stroke="var(--track)" stroke-width="5"></circle>
        ${segs}
        <text x="21" y="22.5" text-anchor="middle" class="donut-num">${total}</text>
        <text x="21" y="26.5" text-anchor="middle" class="donut-sub">groups</text>
      </svg>
      <ul class="legend">
        ${subjects.map((s, i) => `<li><i style="background:${COLORS[i % COLORS.length]}"></i>${esc(s.subject)}<b>${s.count}</b></li>`).join('')}
      </ul>`;
  }

  function renderSeatRing(s) {
    const pct = s.totalSeats ? Math.round(s.filledSeats / s.totalSeats * 100) : 0;
    document.getElementById('seatRing').innerHTML = `
      ${ringSvg(pct, '#6366f1', pct + '%', 'filled')}
      <ul class="legend">
        <li><i style="background:#6366f1"></i>Seats taken<b>${s.filledSeats}</b></li>
        <li><i style="background:#e9ebf5"></i>Seats free<b>${s.openSeats}</b></li>
        <li><i style="background:#ef4444"></i>Groups full<b>${s.fullGroups}</b></li>
        <li><i style="background:#10b981"></i>Total memberships<b>${s.totalMemberships}</b></li>
      </ul>`;
  }

  function renderCapacity(groups) {
    const el = document.getElementById('capacityBars');
    if (!groups.length) { el.innerHTML = '<div class="empty">No groups yet.</div>'; return; }
    const top = groups.slice().sort((a, b) => (b.memberCount / b.maxMembers) - (a.memberCount / a.maxMembers)).slice(0, 6);
    el.innerHTML = top.map(g => `
      <div class="bar-row">
        <span class="t">${esc(g.name)}</span>
        <span class="n">${g.memberCount}/${g.maxMembers}</span>
        ${seatBar(g)}
      </div>`).join('');
  }

  function renderOpen(groups) {
    const el = document.getElementById('openList');
    const open = groups.filter(g => !g.full && !g.joined).slice(0, 5);
    if (!open.length) { el.innerHTML = '<li class="empty" style="display:block">Nothing to join right now. You are in every open group!</li>'; return; }
    el.innerHTML = open.map(g => `
      <li>
        ${avatar(g.name, 40)}
        <div class="grow"><b>${esc(g.name)}</b><small>${esc(g.subject)} · ${g.seatsLeft} seat${g.seatsLeft === 1 ? '' : 's'} left</small></div>
        <button class="btn sm" data-act="join" data-id="${g.id}">Join</button>
      </li>`).join('');
  }

  function renderMine(groups) {
    const el = document.getElementById('myList');
    const mine = groups.filter(g => g.joined);
    if (!mine.length) {
      el.innerHTML = '<li class="empty" style="display:block">You have not joined any group yet. <a href="groups.html">Browse groups</a></li>';
      return;
    }
    el.innerHTML = mine.map(g => `
      <li>
        ${avatar(g.name, 40)}
        <div class="grow"><b>${esc(g.name)}</b><small>${esc(g.subject)} · ${g.memberCount}/${g.maxMembers} members</small></div>
        <a class="btn ghost sm" href="members.html?id=${g.id}">Members</a>
        <button class="btn danger sm" data-act="leave" data-id="${g.id}">Leave</button>
      </li>`).join('');
  }

  bindGroupActions(document.querySelector('.main'), load);
  load();
})();
