(async function () {
  const me = await requireLogin('groups');
  const content = document.getElementById('content');
  const id = new URLSearchParams(location.search).get('id');

  async function load() {
    if (!id) { content.innerHTML = '<div class="card empty">No group selected. <a href="groups.html">Browse groups</a></div>'; return; }
    try {
      const data = await API.get('/api/groups?id=' + encodeURIComponent(id));
      render(data.group, data.members);
    } catch (e) {
      if (e.status === 401) { location.href = 'index.html'; return; }
      content.innerHTML = `<div class="card empty">${esc(e.message)} <a href="groups.html">Browse groups</a></div>`;
    }
  }

  function render(g, members) {
    const accent = colorFor(g.subject);
    const pct = Math.round(g.memberCount / g.maxMembers * 100);
    const ringColor = g.full ? '#ef4444' : (pct >= 70 ? '#f59e0b' : '#6366f1');

    let action;
    if (g.joined) action = `<button class="btn danger" data-act="leave" data-id="${g.id}">Leave group</button>`;
    else if (g.full) action = '<button class="btn full-btn" disabled>Group is full</button>';
    else action = `<button class="btn" data-act="join" data-id="${g.id}">Join group</button>`;
    if (g.createdBy === me.id) action += ` <button class="btn danger" data-act="delete" data-id="${g.id}">🗑 Delete</button>`;

    const dots = Array.from({ length: Math.min(g.maxMembers, 40) }, (_, i) => `<i class="${i < g.memberCount ? 'on' : ''}"></i>`).join('');

    content.innerHTML = `
      <section class="card hero" style="border-top:5px solid ${accent}">
        ${ringSvg(pct, ringColor, g.memberCount + '/' + g.maxMembers, 'members')}
        <div class="info">
          <span class="badge" style="background:${accent}22;color:${accent}">${esc(g.subject)}</span>
          ${g.full ? '<span class="badge bad">Full</span>' : `<span class="badge warn">${g.seatsLeft} seat${g.seatsLeft === 1 ? '' : 's'} left</span>`}
          <h1>${esc(g.name)}</h1>
          <p class="muted" style="margin:0 0 14px">${esc(g.description || 'No description yet.')}</p>
          <p class="muted" style="margin:0 0 16px;font-size:.85rem">Created by <b>${esc(g.creatorName || '')}</b> on ${esc(g.createdAt || '')}</p>
          ${action}
        </div>
      </section>

      <section class="card">
        <h2>Members (${members.length})</h2>
        <div class="members">
          ${members.map(m => `
            <div class="member ${m.studentId === me.id ? 'me' : ''}">
              ${avatar(m.studentName, 44)}
              <div>
                <b>${esc(m.studentName)}${m.studentId === me.id ? ' (you)' : ''} ${m.creator ? '<span class="badge">Creator</span>' : ''}</b>
                <small>${esc(m.studentEmail)}</small>
                <small>Joined ${esc(m.joinedAt || '')}</small>
              </div>
            </div>`).join('')}
        </div>
        <h2 style="margin-top:24px">Seats</h2>
        <div class="seat-dots">${dots}</div>
      </section>`;
  }

  bindGroupActions(content, () => {
    // After deleting, the group no longer exists, so load() shows "Group not found".
    load();
  });
  load();
})();
