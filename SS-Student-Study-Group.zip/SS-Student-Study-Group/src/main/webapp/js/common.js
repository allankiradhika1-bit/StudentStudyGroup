/* Shared helpers used by every page */

const COLORS = ['#6366f1', '#06b6d4', '#f59e0b', '#ec4899', '#10b981', '#8b5cf6', '#ef4444', '#0ea5e9'];

const API = {
  async req(url, opts) {
    const r = await fetch(url, opts);
    let data = null;
    try { data = await r.json(); } catch (e) { /* no body */ }
    if (!r.ok) {
      const err = new Error((data && data.error) || 'Request failed');
      err.status = r.status;
      throw err;
    }
    return data;
  },
  get(url) { return this.req(url); },
  post(url, params) {
    return this.req(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams(params || {})
    });
  }
};

function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function colorFor(text) {
  let h = 0;
  for (const ch of String(text)) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return COLORS[h % COLORS.length];
}

function initials(name) {
  const parts = String(name).trim().split(/\s+/);
  return ((parts[0] || '?')[0] + (parts.length > 1 ? parts[parts.length - 1][0] : '')).toUpperCase();
}

function avatar(name, size) {
  size = size || 36;
  return `<span class="avatar" style="background:${colorFor(name)};width:${size}px;height:${size}px;font-size:${Math.round(size * 0.38)}px">${esc(initials(name))}</span>`;
}

function toast(message, isError) {
  let box = document.getElementById('toasts');
  if (!box) {
    box = document.createElement('div');
    box.id = 'toasts';
    document.body.appendChild(box);
  }
  const t = document.createElement('div');
  t.className = 'toast' + (isError ? ' err' : '');
  t.textContent = message;
  box.appendChild(t);
  setTimeout(() => { t.style.opacity = '0'; t.style.transition = 'opacity .3s'; }, 3200);
  setTimeout(() => t.remove(), 3600);
}

/* ---------- login guard + sidebar ---------- */
async function requireLogin(active) {
  try {
    const me = await API.get('/api/me');
    renderSidebar(active, me);
    return me;
  } catch (e) {
    location.href = 'index.html';
    throw e;
  }
}

function renderSidebar(active, me) {
  const links = [
    ['dashboard', 'dashboard.html', '📊', 'Dashboard'],
    ['groups', 'groups.html', '👥', 'Study Groups'],
    ['create', 'create-group.html', '➕', 'Create Group']
  ];
  const el = document.getElementById('sidebar');
  if (!el) return;
  el.innerHTML = `
    <div class="brand"><span class="logo">📚</span><span>SS Study Group</span></div>
    <nav class="nav">
      ${links.map(l => `<a href="${l[1]}" class="${l[0] === active ? 'active' : ''}"><span>${l[2]}</span>${l[3]}</a>`).join('')}
    </nav>
    <div class="user-card">
      ${avatar(me.name, 38)}
      <div class="who"><b>${esc(me.name)}</b><small>${esc(me.email)}</small></div>
      <button class="logout" id="logoutBtn" title="Log out">Log out</button>
    </div>`;
  document.getElementById('logoutBtn').onclick = async () => {
    try { await API.post('/api/logout'); } catch (e) { /* ignore */ }
    location.href = 'index.html';
  };
}

/* ---------- small chart building blocks ---------- */
function fillClass(g) {
  if (g.full) return 'full';
  return g.memberCount / g.maxMembers >= 0.7 ? 'warn' : '';
}

function seatBar(g) {
  const pct = Math.min(100, Math.round(g.memberCount / g.maxMembers * 100));
  return `<div class="bar"><span class="${fillClass(g)}" style="width:${pct}%"></span></div>`;
}

function ringSvg(pct, color, label, sub) {
  pct = Math.max(0, Math.min(100, pct));
  return `<svg viewBox="0 0 42 42" class="ring">
    <circle r="15.9155" cx="21" cy="21" fill="transparent" stroke="var(--track)" stroke-width="4.5"></circle>
    <circle class="val" r="15.9155" cx="21" cy="21" fill="transparent" stroke="${color}" stroke-width="4.5"
            stroke-linecap="round" stroke-dasharray="${pct} ${100 - pct}" stroke-dashoffset="25"></circle>
    <text x="21" y="22.5" text-anchor="middle" class="ring-txt">${esc(label)}</text>
    <text x="21" y="27" text-anchor="middle" class="ring-sub">${esc(sub || '')}</text>
  </svg>`;
}

/* ---------- group card + actions (used on dashboard and groups page) ---------- */
function groupCard(g, me) {
  const accent = colorFor(g.subject);
  const isOwner = g.createdBy === me.id;
  let status;
  if (g.joined) status = '<span class="badge good">Joined</span>';
  else if (g.full) status = '<span class="badge bad">Full</span>';
  else status = `<span class="badge warn">${g.seatsLeft} seat${g.seatsLeft === 1 ? '' : 's'} left</span>`;

  let main;
  if (g.joined) main = `<button class="btn danger sm" data-act="leave" data-id="${g.id}">Leave group</button>`;
  else if (g.full) main = `<button class="btn full-btn sm" disabled>Group is full</button>`;
  else main = `<button class="btn sm" data-act="join" data-id="${g.id}">Join group</button>`;

  return `
  <article class="card gcard" style="--accent:${accent}">
    <div class="top-row">
      <span class="badge" style="background:${accent}22;color:${accent}">${esc(g.subject)}</span>
      ${status}
    </div>
    <h3>${esc(g.name)}</h3>
    <p class="desc">${esc(g.description || 'No description yet.')}</p>
    <div>
      <div class="meta"><span>👤 ${g.memberCount} / ${g.maxMembers} members</span><span>by ${esc(g.creatorName || '')}</span></div>
      ${seatBar(g)}
    </div>
    <div class="actions">
      ${main}
      <a class="btn ghost sm" href="members.html?id=${g.id}">View members</a>
      ${isOwner ? `<button class="btn danger sm" data-act="delete" data-id="${g.id}" title="Delete group">🗑</button>` : ''}
    </div>
  </article>`;
}

/** Performs join / leave / delete. Resolves true when something changed. */
async function groupAction(act, id) {
  try {
    if (act === 'join') {
      await API.post('/api/join', { groupId: id });
      toast('You joined the group 🎉');
    } else if (act === 'leave') {
      if (!confirm('Leave this group?')) return false;
      await API.post('/api/leave', { groupId: id });
      toast('You left the group');
    } else if (act === 'delete') {
      if (!confirm('Delete this group for everyone? This cannot be undone.')) return false;
      await API.post('/api/groups', { action: 'delete', groupId: id });
      toast('Group deleted');
    }
    return true;
  } catch (e) {
    if (e.status === 401) { location.href = 'index.html'; return false; }
    toast(e.message, true);   // e.g. "This group is full. No places are left."
    return true;              // state may have changed (someone else took the last seat), so refresh
  }
}

/** Wires up click handling for any [data-act] buttons inside `root`. */
function bindGroupActions(root, onChange) {
  root.addEventListener('click', async ev => {
    const btn = ev.target.closest('[data-act]');
    if (!btn) return;
    btn.disabled = true;
    const changed = await groupAction(btn.dataset.act, btn.dataset.id);
    if (changed) onChange(); else btn.disabled = false;
  });
}

function countUp(el, target) {
  const start = performance.now(), dur = 700;
  function tick(now) {
    const p = Math.min(1, (now - start) / dur);
    el.textContent = Math.round(target * (1 - Math.pow(1 - p, 3)));
    if (p < 1) requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
}
