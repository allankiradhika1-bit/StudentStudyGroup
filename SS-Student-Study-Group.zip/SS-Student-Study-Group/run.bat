@echo off
REM Starts the app on http://localhost:8080  (needs JDK 11+ and Maven)
cd /d "%~dp0"
mvn jetty:run
