#!/usr/bin/env bash
# Starts the app on http://localhost:8080  (needs JDK 11+ and Maven)
cd "$(dirname "$0")"
mvn jetty:run
