# SS Student Study Group Management

Students create study groups, join or leave them, see who is in each group, and
groups reject new members once they reach their maximum size.

Java servlets + JDBC (embedded H2 database) + a plain HTML/CSS/JS dashboard.

## Run it on localhost

Requirements: **JDK 11 or newer** and **Maven 3.6+** (internet needed once, to download dependencies).

```
mvn jetty:run
```

(or double-click `run.bat` on Windows, or run `./run.sh` on Mac/Linux)

Then open **http://localhost:8080**. Stop the server with `Ctrl + C`.

On first start the app creates a database in `./data/` and loads demo groups so the
dashboard has something to show. Click **"Try demo account"** on the login page, or log in
with any name and email (new emails are registered automatically).
To reset all data, stop the server and delete the `data/` folder.

To run on Tomcat 9 instead: `mvn package` and copy `target/ss-study-group.war` to Tomcat's `webapps/`.

## Features

| Requirement | Where it is |
|---|---|
| Create groups (name, subject, description) | `create-group.html` -> `POST /api/groups` |
| Join and leave | Buttons on `groups.html` and `members.html` -> `POST /api/join`, `/api/leave` |
| Display each group's members | `members.html?id=..` -> `GET /api/groups?id=..` |
| Maximum members per group | "Maximum members" field when creating (2 to 100) |
| Reject joins when full | `MembershipDAO.join()` checks capacity inside a locked transaction; the API answers HTTP 409 and the UI shows a "Group is full" message |
| Search by name or subject, show groups with free places | Search box, "Open seats only" and "My groups" filters on `groups.html` |
| Visual dashboard | `dashboard.html`: stat cards, subject donut chart, seat-usage ring, capacity bars |

## Project layout

```
src/main/java/com/ssstudygroup/
  model/    Student, StudyGroup, Membership
  dao/      StudentDAO, GroupDAO, MembershipDAO     (all SQL lives here)
  servlet/  LoginServlet, GroupServlet, JoinServlet, LeaveServlet, StatsServlet
  util/     DBConnection (JDBC + table creation + demo data), ApiUtil, AppInitListener
src/main/webapp/
  index.html (login)  dashboard.html  groups.html  create-group.html  members.html
  css/style.css       js/common.js  dashboard.js  groups.js  create-group.js  members.js
  WEB-INF/web.xml     servlet URL mappings
pom.xml
```

## REST endpoints

| Method | URL | Purpose |
|---|---|---|
| POST | `/api/login` (`name`, `email`) | Log in or register |
| POST | `/api/logout` | Log out |
| GET | `/api/me` | Current student |
| GET | `/api/groups?q=&available=true&mine=true` | List and search groups |
| GET | `/api/groups?id=5` | One group with its members |
| POST | `/api/groups` (`name`, `subject`, `description`, `maxMembers`) | Create group |
| POST | `/api/groups` (`action=delete`, `groupId`) | Delete group (creator only) |
| POST | `/api/join` (`groupId`) | Join (409 if full or already a member) |
| POST | `/api/leave` (`groupId`) | Leave |
| GET | `/api/stats` | Dashboard numbers |

## Using MySQL instead of H2

Replace the H2 dependency in `pom.xml` with the MySQL connector, change the URL, user and
password in `DBConnection.java` (or pass `-Dssg.db.url=...`), and change `Class.forName` to the
MySQL driver. The SQL uses `AUTO_INCREMENT`, which MySQL also supports.
